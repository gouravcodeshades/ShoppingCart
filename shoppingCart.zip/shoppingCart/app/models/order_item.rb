class OrderItem < ApplicationRecord
end
