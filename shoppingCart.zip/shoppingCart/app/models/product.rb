class Product < ApplicationRecord
	belongs_to :admin
end
