class OrderItemsController < ApplicationController
  #before_action :set_order_item, only: %i[ show edit update destroy ]

  # GET /order_items/1/edit
  def edit
  end

  # POST /order_items or /order_items.json
  def create
    @order = current_order
    @order_item = @order.order_items.new(order_params)
    @order.save
    session[:order_id] = @order.id
  end

  # PATCH/PUT /order_items/1 or /order_items/1.json
  def update
    @order = current_order
    @order_item = @order.order_items.find(params[:id])
    @order_item.update_attributes(order_params)
    @order_items = current_order.order_items
   
  end

  # DELETE /order_items/1 or /order_items/1.json
  def destroy
    @order = current_order
    @order_item = @order.order_items.find(params[:id])
    @order_item.destroy
    @order_items = current_order.order_items
  end

  private

    # Only allow a list of trusted parameters through.
    def order_item_params
      params.require(:order_item).permit(:quantity, :product_id)
    end
end
