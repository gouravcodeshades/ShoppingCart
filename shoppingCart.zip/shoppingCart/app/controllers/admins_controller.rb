class AdminsController < ApplicationController
end
