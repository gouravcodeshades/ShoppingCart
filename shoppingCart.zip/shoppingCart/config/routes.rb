Rails.application.routes.draw do
  get 'shop/index'
  get 'shop/show'
  resources :order_items
  resources :orders
  # Define your application routes per the DSL in https://guides.rubyonrails.org/routing.html

  # Defines the root path route ("/")
  root "products#index"
  resources :products
  devise_for :admins
  resources :admins
end
